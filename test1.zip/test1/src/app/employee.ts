export class Employee {
    EmployeeId: number;
    EmployeeName: string;
    EmployeeSalary: number;
}