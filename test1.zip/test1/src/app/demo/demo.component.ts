import { Component, OnInit } from '@angular/core';
import { ShowDetails } from '../models/showdetails';
import { DataService } from '../services/data.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css'],
  providers: [UserService]
})
export class DemoComponent implements OnInit {

    public showDetail: ShowDetails;
    public msg: string;
    public user_title: string;

  constructor(private _dataService: DataService, private _userService: UserService) { 
      this.msg = this._dataService.message;
      this.user_title = this._userService.title;
      this.showDetail = new ShowDetails();
  }

  ngOnInit() {
  }
  
  doCall() {
      console.log('doCall invoked..')
      return this.showDetail.display();
  }
  
  doClickMe() {
      return this._userService.userDetails();
  }

}
