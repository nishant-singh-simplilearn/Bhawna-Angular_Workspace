import { Injectable } from '@angular/core';

@Injectable()
export class DataService {
    message: string = "Welcome to Simplilearn!!"
}