import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
    
    title:string = "User Management System!!";
    
    userDetails() {
        return "Displaying User Details Here..";
    }
}