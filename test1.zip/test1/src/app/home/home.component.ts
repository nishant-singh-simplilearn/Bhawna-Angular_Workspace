import { Component, OnInit } from '@angular/core';
import { DirectionEnum } from './directionenum';
@Component({
  selector: 'app-home',
   templateUrl: './home.component.html',
   styleUrls: ['./home.component.css']
})
export class HomeComponent {
    dirEnum = DirectionEnum;
    myDir = DirectionEnum.East;
    name = "King";
    numbers = [1, 2, 3, 4, 5, 6];
}
