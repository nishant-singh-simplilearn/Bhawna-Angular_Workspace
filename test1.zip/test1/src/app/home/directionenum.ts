
export enum DirectionEnum {
    East, West, North, South
}