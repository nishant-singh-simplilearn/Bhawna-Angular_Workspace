export class Account {
    public AccountId: number;
    public AccountName: string;
     constructor() {
        this.AccountId = 5001;
        this.AccountName = "king.kochhar";
    }
}