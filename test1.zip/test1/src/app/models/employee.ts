export class Employee {
    public EmployeeId: number;
    public EmployeeName: string;
    constructor() {
        this.EmployeeId = 1001;
        this.EmployeeName = "King Kochhar";
    }
}