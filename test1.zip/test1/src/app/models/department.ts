export class Department {
    public DepartmentId: number;
    public DepartmentName: string;
    
     constructor() {
        this.DepartmentId = 10;
        this.DepartmentName = "Sales and Marketing";
    }
}