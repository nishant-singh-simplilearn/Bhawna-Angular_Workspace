import { Account } from '../models/account';
import { Employee } from './employee';
import { Department } from './department';

export class ShowDetails {
    public emp: Employee;
    public acc: Account;
    public dept: Department;
    
    constructor() {
        this.emp = new Employee();
        this.acc = new Account();
        this.dept = new Department();
    }
    
    display() {
        console.log(this.emp.EmployeeId)
        return `${this.emp.EmployeeId}, ${this.emp.EmployeeName}, 
        ${this.dept.DepartmentId}, ${this.dept.DepartmentName},
        ${this.acc.AccountId}, ${this.acc.AccountName}`
    }
}