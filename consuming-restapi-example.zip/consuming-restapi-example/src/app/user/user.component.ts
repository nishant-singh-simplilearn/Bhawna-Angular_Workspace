import { Component, OnInit } from '@angular/core';

import { DataService } from '../services/data.service';
import { UserService } from '../services/user.service';

import { User } from '../models/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: []
})
export class UserComponent implements OnInit {

    data_message: string;
    user_message: string;
    
    userList: User[];

  constructor(private _dataService: DataService, private _userService: UserService) { 
      this.data_message = _dataService.message;
      this.user_message = _userService.message;
  }

  ngOnInit() {
     
      this._userService.getUsers().subscribe(res => {
          this.userList = res;
          console.log(this.userList);
      })
  }

}
