import { Injectable } from '@angular/core';
import { HttpClient, Response } from '@angular/common/http';
import { Observable } from 'rxjs';

import {User} from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
    
    message: string = "Hello from User Service";

    constructor(private _http: HttpClient) { }
    
    getUsers(): Observable<User[]> {
        return this._http.get<User[]>("https://jsonplaceholder.typicode.com/users")
    }
    
     getUserList(): Promise<User[]> {
        return this._http.get("https://jsonplaceholder.typicode.com/users").toPromise()
        .then(this.extractData)
        .catch(this.handleError)
    }
    
    extractData(res: Response) {
        let body = res;
        return body;
    }
    
    handleError(error: Response | any) {
        console.log(error.message || error);
    }
}
